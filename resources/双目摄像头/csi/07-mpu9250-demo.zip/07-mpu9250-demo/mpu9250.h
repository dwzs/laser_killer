/**
 ******************************************************************************
 * @file    mpu9250.h
 * @author
 * @version V1.0
 * @date
 * @brief
 ***************************************************************************
 */
#ifndef __MPU9250_H__
#define __MPU9250_H__

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <linux/i2c-dev.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <fcntl.h>
#include <stdint.h>
#include <stddef.h>
#include <math.h>

typedef uint8_t bool;
#define true 1
#define false 0

/* define Sensitivity Scale Factor*/
#define GYRO_SSF_AT_FS_250DPS (131)   /* LSB/dps */
#define GYRO_SSF_AT_FS_500DPS (65.5)  /* LSB/dps */
#define GYRO_SSF_AT_FS_1000DPS (32.8) /* LSB/dps */
#define GYRO_SSF_AT_FS_2000DPS (16.4) /* LSB/dps */
#define ACCEL_SSF_AT_FS_2g (16384)    /* LSB/g  */
#define ACCEL_SSF_AT_FS_4g (8192)     /* LSB/g  */
#define ACCEL_SSF_AT_FS_8g (4096)     /* LSB/g  */
#define ACCEL_SSF_AT_FS_16g (2048)    /* LSB/g  */
#define MAG_SSF_AT_FS_4800uT (0.6)    /* uT/LSB */

/* define Device I2C address*/
#define I2C_ADD_MPU9250 0x68
#define GYRO_ADDRESS I2C_ADD_MPU9250 // Gyro and Accel device address
#define ACCEL_ADDRESS I2C_ADD_MPU9250
#define MAG_ADDRESS 0x0C // compass device address

#define ADDRESS_AD0_LOW 0xD0  // address pin low (GND), default for InvenSense evaluation board
#define ADDRESS_AD0_HIGH 0xD1 // address pin high (VCC)
#define DEFAULT_ADDRESS GYRO_ADDRESS
#define REG_VAL_WIA 0x71 // identity of MPU9250 is 0x71.

/* define MPU9250 register address */
#define REG_ADD_SMPLRT_DIV 0x19   // Sample Rate Divider. Typical values:0x07(125Hz) 1KHz internal sample rate
#define REG_ADD_CONFIG 0x1A       // Low Pass Filter.Typical values:0x06(5Hz)
#define REG_ADD_GYRO_CONFIG 0x1B  // Gyro Full Scale Select. Typical values:0x10(1000dps)
#define REG_ADD_ACCEL_CONFIG 0x1C // Accel Full Scale Select. Typical values:0x01(2g)

#define REG_ADD_ACCEL_XOUT_H 0x3B
#define REG_ADD_ACCEL_XOUT_L 0x3C
#define REG_ADD_ACCEL_YOUT_H 0x3D
#define REG_ADD_ACCEL_YOUT_L 0x3E
#define REG_ADD_ACCEL_ZOUT_H 0x3F
#define REG_ADD_ACCEL_ZOUT_L 0x40

#define REG_ADD_TEMP_OUT_H 0x41
#define REG_ADD_TEMP_OUT_L 0x42

#define REG_ADD_GYRO_XOUT_H 0x43
#define REG_ADD_GYRO_XOUT_L 0x44
#define REG_ADD_GYRO_YOUT_H 0x45
#define REG_ADD_GYRO_YOUT_L 0x46
#define REG_ADD_GYRO_ZOUT_H 0x47
#define REG_ADD_GYRO_ZOUT_L 0x48

#define REG_ADD_MAG_XOUT_L 0x03
#define REG_ADD_MAG_XOUT_H 0x04
#define REG_ADD_MAG_YOUT_L 0x05
#define REG_ADD_MAG_YOUT_H 0x06
#define REG_ADD_MAG_ZOUT_L 0x07
#define REG_ADD_MAG_ZOUT_H 0x08

#define REG_ADD_PWR_MGMT_1 0x6B // Power Management. Typical values:0x00(run mode)
#define REG_ADD_WHO_AM_I 0x75   // identity of the device
/* define MPU9250 register address end */

#define MAG_DATA_LEN 6

#ifdef __cplusplus
extern "C"
{
#endif

  typedef enum
  {
    IMU_EN_SENSOR_TYPE_NULL = 0,
    IMU_EN_SENSOR_TYPE_MPU9250,
    IMU_EN_SENSOR_TYPE_MAX
  } IMU_EN_SENSOR_TYPE;

  typedef struct imu_st_sensor_reg_data_tag
  {
    int16_t s16X;
    int16_t s16Y;
    int16_t s16Z;
  } IMU_ST_SENSOR_REG_DATA;

  typedef struct imu_st_angles_data_tag
  {
    float fYaw;
    float fPitch;
    float fRoll;
  } IMU_ST_ANGLES_DATA;

  typedef struct imu_st_sensor_data_tag
  {
    float fX;
    float fY;
    float fZ;
  } IMU_ST_SENSOR_DATA;

  typedef struct mpu9250_st_avg_data_tag
  {
    uint8_t u8Index;
    int16_t s16AvgBuffer[8];
  } MPU9250_ST_AVG_DATA;

  void imuInit(IMU_EN_SENSOR_TYPE *penMotionSensorType);
  void imuDataGet(IMU_ST_ANGLES_DATA *pstAngles,
                  IMU_ST_SENSOR_DATA *pstGyroRawData,
                  IMU_ST_SENSOR_DATA *pstAccelRawData,
                  IMU_ST_SENSOR_DATA *pstMagnRawData);

  uint8_t I2C_ReadOneByte(uint8_t DevAddr, uint8_t RegAddr);
  void I2C_WriteOneByte(uint8_t DevAddr, uint8_t RegAddr, uint8_t value);

#ifdef __cplusplus
}
#endif

#endif //__MPU9250_H__
