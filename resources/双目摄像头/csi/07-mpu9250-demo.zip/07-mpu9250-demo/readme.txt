#Build:
$make

#Run:
$./mpu9250_demo

